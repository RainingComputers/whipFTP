import pip

pip.main(['install', 'paramiko'])
pip.main(['install', 'psutil'])